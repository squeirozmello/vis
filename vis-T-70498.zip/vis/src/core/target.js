function d3_target(d) {
  return d.target;
}
