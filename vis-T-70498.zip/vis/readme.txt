Hi, welcome to my VIS project.

In order to run the project you should run the following command to launch a Python simple server:

python -m SimpleHTTPServer 8000

To find the views, please introduce the following urls in your web browser:
http://localhost:8000/questionX.html

X - number of the visualisation [1,5]


